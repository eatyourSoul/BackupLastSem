from fastapi import FastAPI
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer

app = FastAPI()

# Load trained model & vectorizer
model = joblib.load("phishing_model.pkl")
vectorizer = joblib.load("vectorizer.pkl")

@app.post("/predict/")
def predict_message(message: str):
    cleaned_message = [" ".join(message.lower().split())]  # Basic cleaning
    transformed_message = vectorizer.transform(cleaned_message)
    prediction = model.predict(transformed_message)[0]
    return {"message": message, "prediction": "Phishing" if prediction == 1 else "Legitimate"}
