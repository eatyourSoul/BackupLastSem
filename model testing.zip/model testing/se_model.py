import pandas as pd
import joblib
import re
import string
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression

# Sample dataset (phishing vs legitimate messages)
data = {
    "text": [
        "Your account is locked! Click here to verify.",
        "Dear user, urgent payment is needed to avoid account suspension.",
        "We detected suspicious activity on your bank account. Click here to reset your password.",
        "Urgent: Your PayPal account is on hold. Verify now.",
        "Congratulations! You've won $1000. Claim now!",
        "Hello, your interview is scheduled for Monday at 10 AM.",
        "Your Amazon order is confirmed. Thanks for shopping with us!",
        "Meeting reminder: 3 PM today.",
        "Invoice for your recent purchase is attached."
    ],
    "label": [1, 1, 1, 1, 1, 0, 0, 0, 0]  # 1 = Phishing, 0 = Legitimate
}



df = pd.DataFrame(data)

# Function to clean text
def clean_text(text):
    text = text.lower()
    text = re.sub(r'\d+', '', text)  # Remove numbers
    text = text.translate(str.maketrans('', '', string.punctuation))  # Remove punctuation
    text = re.sub(r'\s+', ' ', text).strip()  # Remove extra spaces
    return text

df["clean_text"] = df["text"].apply(clean_text)

# Convert Text to Features (TF-IDF)
vectorizer = TfidfVectorizer(max_features=500)
X = vectorizer.fit_transform(df["clean_text"])
y = df["label"]

# Train Model
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = LogisticRegression()
model.fit(X_train, y_train)

# Save Model & Vectorizer
joblib.dump(model, "phishing_model.pkl")
joblib.dump(vectorizer, "vectorizer.pkl")

print("✅ Model trained and saved!") 
